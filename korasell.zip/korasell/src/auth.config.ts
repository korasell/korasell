import type { NextAuthConfig } from "next-auth";

/**
 * Configuration "edge-safe" : ne contient ni le PrismaAdapter ni le provider
 * Credentials (qui utilisent bcrypt/Prisma, incompatibles avec le runtime Edge).
 * Utilisée uniquement par middleware.ts pour vérifier les sessions.
 * La configuration complète est dans auth.ts.
 */
export const authConfig = {
  pages: {
    signIn: "/login",
  },
  session: {
    strategy: "jwt",
  },
  callbacks: {
    authorized({ auth, request }) {
      const isLoggedIn = !!auth?.user;
      const { pathname } = request.nextUrl;

      const isSellerRoute = pathname.startsWith("/dashboard/vendeur");
      const isAdminRoute = pathname.startsWith("/dashboard/admin");
      const isCommandesRoute = pathname.startsWith("/dashboard/commandes");

      if (isSellerRoute) {
        return isLoggedIn && ["SELLER", "ADMIN"].includes(auth!.user.role);
      }

      if (isAdminRoute) {
        return isLoggedIn && auth!.user.role === "ADMIN";
      }

      if (isCommandesRoute) {
        return isLoggedIn;
      }

      return true;
    },
    jwt({ token, user }) {
      if (user) {
        token.id = user.id;
        token.role = user.role;
      }
      return token;
    },
    session({ session, token }) {
      if (session.user) {
        session.user.id = token.id as string;
        session.user.role = token.role as "BUYER" | "SELLER" | "ADMIN";
      }
      return session;
    },
  },
  providers: [], // renseignés dans auth.ts
} satisfies NextAuthConfig;
