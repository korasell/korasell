import { z } from "zod";

export const checkoutSchema = z.object({
  productId: z.string().min(1),
  quantity: z.coerce.number().int().min(1).max(50).default(1),
  shippingName: z.string().max(120).optional(),
  shippingAddress: z.string().max(300).optional(),
  shippingCity: z.string().max(120).optional(),
  shippingPhone: z.string().max(40).optional(),
});

export type CheckoutInput = z.infer<typeof checkoutSchema>;
