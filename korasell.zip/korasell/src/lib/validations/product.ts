import { z } from "zod";

const baseProductSchema = z.object({
  title: z.string().min(3, "Le titre doit contenir au moins 3 caractères").max(120),
  description: z.string().max(5000).optional().or(z.literal("")),
  type: z.enum(["DIGITAL", "PHYSICAL", "SERVICE"]),
  priceCents: z.coerce
    .number()
    .int()
    .min(100, "Le prix minimum est de 1 (100 = 1 unité de monnaie)"),
  currency: z.string().default("XOF"),
  images: z.array(z.string().url()).max(8).default([]),

  // Physique
  stockQuantity: z.coerce.number().int().min(0).optional(),

  // Numérique
  digitalFileUrl: z.string().url().optional().or(z.literal("")),
  digitalLinkUrl: z.string().url().optional().or(z.literal("")),

  // Service
  serviceDurationMinutes: z.coerce.number().int().min(1).optional(),
  serviceLocation: z.string().max(200).optional().or(z.literal("")),
});

export const productSchema = baseProductSchema.superRefine((data, ctx) => {
  if (data.type === "PHYSICAL" && data.stockQuantity === undefined) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: "Le stock est requis pour un produit physique.",
      path: ["stockQuantity"],
    });
  }

  if (
    data.type === "DIGITAL" &&
    !data.digitalFileUrl &&
    !data.digitalLinkUrl
  ) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message:
        "Un fichier ou un lien de livraison est requis pour un produit numérique.",
      path: ["digitalFileUrl"],
    });
  }

  if (data.type === "SERVICE" && !data.serviceDurationMinutes) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: "La durée est requise pour un service.",
      path: ["serviceDurationMinutes"],
    });
  }
});

export type ProductInput = z.infer<typeof baseProductSchema>;

export const productStatusSchema = z.object({
  status: z.enum(["DRAFT", "PUBLISHED", "ARCHIVED"]),
});
