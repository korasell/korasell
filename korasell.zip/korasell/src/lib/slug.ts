import { customAlphabet } from "nanoid";

const suffixGenerator = customAlphabet(
  "0123456789abcdefghijklmnopqrstuvwxyz",
  6
);

/**
 * Transforme un texte libre en slug URL-safe.
 * Ex: "Ma Super Boutique !" -> "ma-super-boutique"
 */
export function slugify(input: string): string {
  return input
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "") // retire les accents
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
}

/**
 * Vérifie l'unicité d'un slug via une fonction de recherche fournie
 * (ex: (slug) => prisma.store.findUnique({ where: { slug } })),
 * et ajoute un suffixe aléatoire en cas de collision.
 */
export async function generateUniqueSlug(
  base: string,
  exists: (slug: string) => Promise<unknown | null>
): Promise<string> {
  const baseSlug = slugify(base) || "item";
  let candidate = baseSlug;
  let attempts = 0;

  while (await exists(candidate)) {
    attempts += 1;
    candidate = `${baseSlug}-${suffixGenerator()}`;
    if (attempts > 10) {
      throw new Error("Impossible de générer un slug unique.");
    }
  }

  return candidate;
}
