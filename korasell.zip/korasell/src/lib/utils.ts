import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Formate un montant stocké dans la plus petite unité Stripe pour la devise.
 * XOF est une devise "zero-decimal" chez Stripe (comme JPY) : la valeur
 * stockée est directement le montant en FCFA, sans conversion ×100.
 */
export function formatPrice(amount: number, currency: string = "XOF"): string {
  if (currency === "XOF") {
    return `${amount.toLocaleString("fr-FR")} FCFA`;
  }
  return new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency,
  }).format(amount / 100);
}
