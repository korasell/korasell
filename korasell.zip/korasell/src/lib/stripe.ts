import Stripe from "stripe";

if (!process.env.STRIPE_SECRET_KEY) {
  // Ne bloque pas le build, mais échouera clairement à l'exécution si absent.
  console.warn("STRIPE_SECRET_KEY n'est pas défini.");
}

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY ?? "", {
  apiVersion: "2024-09-30.acacia",
});

// Commission de la plateforme (10%)
export const PLATFORM_FEE_PERCENT = 10;

export function computeApplicationFee(totalCents: number): number {
  return Math.round((totalCents * PLATFORM_FEE_PERCENT) / 100);
}
