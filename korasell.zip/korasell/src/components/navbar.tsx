import Link from "next/link";
import { auth, signOut } from "@/auth";

export async function Navbar() {
  const session = await auth();

  const dashboardHref =
    session?.user.role === "ADMIN"
      ? "/dashboard/admin"
      : session?.user.role === "SELLER"
        ? "/dashboard/vendeur"
        : null;

  return (
    <header className="border-b border-slate-200 bg-white">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
        <Link href="/" className="text-lg font-bold text-primary">
          Korasell
        </Link>

        <div className="flex items-center gap-4 text-sm">
          {session?.user ? (
            <>
              {dashboardHref && (
                <Link href={dashboardHref} className="hover:underline">
                  Mon tableau de bord
                </Link>
              )}
              <form
                action={async () => {
                  "use server";
                  await signOut({ redirectTo: "/" });
                }}
              >
                <button className="rounded-lg bg-slate-100 px-3 py-1.5 hover:bg-slate-200">
                  Se déconnecter
                </button>
              </form>
            </>
          ) : (
            <>
              <Link href="/login" className="hover:underline">
                Connexion
              </Link>
              <Link
                href="/register"
                className="rounded-lg bg-primary px-3 py-1.5 text-primary-foreground hover:opacity-90"
              >
                Créer un compte
              </Link>
            </>
          )}
        </div>
      </nav>
    </header>
  );
}
