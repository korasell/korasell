"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

type Status = "PROCESSING" | "SHIPPED" | "DELIVERED" | "COMPLETED";

const OPTIONS: { value: Status; label: string }[] = [
  { value: "PROCESSING", label: "En préparation" },
  { value: "SHIPPED", label: "Expédiée" },
  { value: "DELIVERED", label: "Livrée" },
  { value: "COMPLETED", label: "Terminée" },
];

export function OrderStatusSelect({
  orderId,
  currentStatus,
}: {
  orderId: string;
  currentStatus: string;
}) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function handleChange(status: Status) {
    setLoading(true);
    await fetch(`/api/vendeur/commandes/${orderId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    setLoading(false);
    router.refresh();
  }

  return (
    <select
      defaultValue={
        OPTIONS.some((o) => o.value === currentStatus)
          ? currentStatus
          : "PROCESSING"
      }
      disabled={loading}
      onChange={(e) => handleChange(e.target.value as Status)}
      className="rounded-lg border border-slate-300 px-3 py-2 text-sm disabled:opacity-50"
    >
      {OPTIONS.map((o) => (
        <option key={o.value} value={o.value}>
          {o.label}
        </option>
      ))}
    </select>
  );
}
