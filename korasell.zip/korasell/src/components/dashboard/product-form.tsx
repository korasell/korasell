"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

type ProductType = "DIGITAL" | "PHYSICAL" | "SERVICE";

type ProductData = {
  id: string;
  title: string;
  description: string | null;
  type: ProductType;
  priceCents: number;
  stockQuantity: number | null;
  digitalFileUrl: string | null;
  digitalLinkUrl: string | null;
  serviceDurationMinutes: number | null;
  serviceLocation: string | null;
  images: { url: string }[];
} | null;

export function ProductForm({
  storeId,
  product,
}: {
  storeId: string;
  product: ProductData;
}) {
  const router = useRouter();
  const [type, setType] = useState<ProductType>(product?.type ?? "DIGITAL");
  const [images, setImages] = useState<string[]>(
    product?.images.map((i) => i.url) ?? []
  );
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleImageUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setUploading(true);
    setError(null);

    for (const file of Array.from(files).slice(0, 8 - images.length)) {
      const formData = new FormData();
      formData.append("file", file);
      const res = await fetch("/api/upload", { method: "POST", body: formData });
      const data = await res.json();
      if (res.ok) {
        setImages((prev) => [...prev, data.url]);
      } else {
        setError(data.error ?? "Échec de l'upload d'une image");
      }
    }

    setUploading(false);
  }

  function removeImage(url: string) {
    setImages((prev) => prev.filter((i) => i !== url));
  }

  async function handleSubmit(formData: FormData) {
    setError(null);
    setLoading(true);

    const priceUnits = Number(formData.get("price"));

    const payload = {
      title: formData.get("title"),
      description: formData.get("description"),
      type,
      priceCents: Math.round(priceUnits),
      currency: "XOF",
      images,
      stockQuantity: formData.get("stockQuantity")
        ? Number(formData.get("stockQuantity"))
        : undefined,
      digitalFileUrl: formData.get("digitalFileUrl") || undefined,
      digitalLinkUrl: formData.get("digitalLinkUrl") || undefined,
      serviceDurationMinutes: formData.get("serviceDurationMinutes")
        ? Number(formData.get("serviceDurationMinutes"))
        : undefined,
      serviceLocation: formData.get("serviceLocation") || undefined,
    };

    const res = await fetch(
      product ? `/api/products/${product.id}` : "/api/products",
      {
        method: product ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(product ? payload : { ...payload, storeId }),
      }
    );

    setLoading(false);

    if (!res.ok) {
      const data = await res.json();
      setError(
        typeof data.error === "string"
          ? data.error
          : "Vérifiez les champs du formulaire."
      );
      return;
    }

    router.push("/dashboard/vendeur/produits");
    router.refresh();
  }

  return (
    <form action={handleSubmit} className="max-w-lg space-y-4">
      <div>
        <label htmlFor="title" className="mb-1 block text-sm font-medium">
          Titre du produit
        </label>
        <input
          id="title"
          name="title"
          type="text"
          defaultValue={product?.title}
          required
          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-primary focus:outline-none"
        />
      </div>

      <div>
        <label
          htmlFor="description"
          className="mb-1 block text-sm font-medium"
        >
          Description
        </label>
        <textarea
          id="description"
          name="description"
          rows={4}
          defaultValue={product?.description ?? ""}
          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-primary focus:outline-none"
        />
      </div>

      <div>
        <span className="mb-1 block text-sm font-medium">Type de produit</span>
        <div className="flex gap-2">
          {(["DIGITAL", "PHYSICAL", "SERVICE"] as ProductType[]).map((t) => (
            <button
              type="button"
              key={t}
              onClick={() => setType(t)}
              className={`rounded-lg border px-3 py-1.5 text-sm ${
                type === t
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-slate-300"
              }`}
            >
              {t === "DIGITAL"
                ? "Numérique"
                : t === "PHYSICAL"
                  ? "Physique"
                  : "Service"}
            </button>
          ))}
        </div>
      </div>

      <div>
        <label htmlFor="price" className="mb-1 block text-sm font-medium">
          Prix (FCFA)
        </label>
        <input
          id="price"
          name="price"
          type="number"
          min={1}
          step="1"
          defaultValue={product ? product.priceCents : undefined}
          required
          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-primary focus:outline-none"
        />
      </div>

      {type === "PHYSICAL" && (
        <div>
          <label
            htmlFor="stockQuantity"
            className="mb-1 block text-sm font-medium"
          >
            Stock disponible
          </label>
          <input
            id="stockQuantity"
            name="stockQuantity"
            type="number"
            min={0}
            defaultValue={product?.stockQuantity ?? undefined}
            required
            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-primary focus:outline-none"
          />
        </div>
      )}

      {type === "DIGITAL" && (
        <>
          <div>
            <label
              htmlFor="digitalFileUrl"
              className="mb-1 block text-sm font-medium"
            >
              Lien du fichier (livré automatiquement après paiement)
            </label>
            <input
              id="digitalFileUrl"
              name="digitalFileUrl"
              type="url"
              placeholder="https://..."
              defaultValue={product?.digitalFileUrl ?? ""}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-primary focus:outline-none"
            />
          </div>
          <div>
            <label
              htmlFor="digitalLinkUrl"
              className="mb-1 block text-sm font-medium"
            >
              Ou lien d&apos;accès (ex: lien privé, invitation)
            </label>
            <input
              id="digitalLinkUrl"
              name="digitalLinkUrl"
              type="url"
              placeholder="https://..."
              defaultValue={product?.digitalLinkUrl ?? ""}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-primary focus:outline-none"
            />
          </div>
        </>
      )}

      {type === "SERVICE" && (
        <>
          <div>
            <label
              htmlFor="serviceDurationMinutes"
              className="mb-1 block text-sm font-medium"
            >
              Durée (minutes)
            </label>
            <input
              id="serviceDurationMinutes"
              name="serviceDurationMinutes"
              type="number"
              min={1}
              defaultValue={product?.serviceDurationMinutes ?? undefined}
              required
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-primary focus:outline-none"
            />
          </div>
          <div>
            <label
              htmlFor="serviceLocation"
              className="mb-1 block text-sm font-medium"
            >
              Lieu / modalité (optionnel)
            </label>
            <input
              id="serviceLocation"
              name="serviceLocation"
              type="text"
              placeholder="En ligne, à domicile..."
              defaultValue={product?.serviceLocation ?? ""}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-primary focus:outline-none"
            />
          </div>
        </>
      )}

      <div>
        <label className="mb-1 block text-sm font-medium">
          Images ({images.length}/8)
        </label>
        <div className="mb-2 flex flex-wrap gap-2">
          {images.map((url) => (
            <div key={url} className="relative">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={url}
                alt=""
                className="h-20 w-20 rounded-md object-cover"
              />
              <button
                type="button"
                onClick={() => removeImage(url)}
                className="absolute -right-1 -top-1 rounded-full bg-slate-900 px-1.5 text-xs text-white"
              >
                ×
              </button>
            </div>
          ))}
        </div>
        {images.length < 8 && (
          <input
            type="file"
            accept="image/png,image/jpeg,image/webp"
            multiple
            onChange={handleImageUpload}
            className="text-sm"
          />
        )}
        {uploading && (
          <p className="mt-1 text-xs text-slate-500">Envoi en cours...</p>
        )}
      </div>

      {error && <p className="text-sm text-red-600">{error}</p>}

      <button
        type="submit"
        disabled={loading || uploading}
        className="rounded-lg bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90 disabled:opacity-50"
      >
        {loading
          ? "Enregistrement..."
          : product
            ? "Mettre à jour le produit"
            : "Créer le produit (brouillon)"}
      </button>
    </form>
  );
}
