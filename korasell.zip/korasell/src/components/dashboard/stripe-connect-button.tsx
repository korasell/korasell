"use client";

import { useState } from "react";

export function StripeConnectButton({
  storeId,
  payoutsEnabled,
}: {
  storeId: string;
  payoutsEnabled: boolean;
}) {
  const [loading, setLoading] = useState(false);

  async function handleClick() {
    setLoading(true);
    const res = await fetch("/api/stripe/connect", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ storeId }),
    });
    const data = await res.json();
    setLoading(false);
    if (res.ok) {
      window.location.href = data.url;
    }
  }

  if (payoutsEnabled) {
    return (
      <div className="flex items-center gap-2 rounded-lg bg-green-50 px-3 py-2 text-sm text-green-700">
        ✓ Paiements activés
        <button
          onClick={handleClick}
          className="text-xs underline"
          disabled={loading}
        >
          Gérer
        </button>
      </div>
    );
  }

  return (
    <button
      onClick={handleClick}
      disabled={loading}
      className="rounded-lg bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90 disabled:opacity-50"
    >
      {loading ? "Redirection..." : "Activer les paiements avec Stripe"}
    </button>
  );
}
