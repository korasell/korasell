"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

type StoreData = {
  id: string;
  name: string;
  description: string | null;
  logoUrl: string | null;
} | null;

export function StoreForm({ store }: { store: StoreData }) {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [logoUrl, setLogoUrl] = useState(store?.logoUrl ?? "");
  const [uploading, setUploading] = useState(false);

  async function handleLogoUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    const formData = new FormData();
    formData.append("file", file);

    const res = await fetch("/api/upload", { method: "POST", body: formData });
    const data = await res.json();
    setUploading(false);

    if (res.ok) {
      setLogoUrl(data.url);
    } else {
      setError(data.error ?? "Échec de l'upload du logo");
    }
  }

  async function handleSubmit(formData: FormData) {
    setError(null);
    setLoading(true);

    const payload = {
      name: formData.get("name"),
      description: formData.get("description"),
      logoUrl,
    };

    const res = await fetch(
      store ? `/api/stores/${store.id}` : "/api/stores",
      {
        method: store ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      }
    );

    setLoading(false);

    if (!res.ok) {
      const data = await res.json();
      setError(
        typeof data.error === "string"
          ? data.error
          : "Vérifiez les champs du formulaire."
      );
      return;
    }

    router.push("/dashboard/vendeur");
    router.refresh();
  }

  return (
    <form action={handleSubmit} className="max-w-lg space-y-4">
      <div>
        <label htmlFor="name" className="mb-1 block text-sm font-medium">
          Nom de la boutique
        </label>
        <input
          id="name"
          name="name"
          type="text"
          defaultValue={store?.name}
          required
          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-primary focus:outline-none"
        />
      </div>

      <div>
        <label
          htmlFor="description"
          className="mb-1 block text-sm font-medium"
        >
          Description
        </label>
        <textarea
          id="description"
          name="description"
          rows={4}
          defaultValue={store?.description ?? ""}
          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-primary focus:outline-none"
        />
      </div>

      <div>
        <label className="mb-1 block text-sm font-medium">Logo</label>
        {logoUrl && (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={logoUrl}
            alt="Logo"
            className="mb-2 h-16 w-16 rounded-full object-cover"
          />
        )}
        <input
          type="file"
          accept="image/png,image/jpeg,image/webp"
          onChange={handleLogoUpload}
          className="text-sm"
        />
        {uploading && (
          <p className="mt-1 text-xs text-slate-500">Envoi en cours...</p>
        )}
      </div>

      {error && <p className="text-sm text-red-600">{error}</p>}

      <button
        type="submit"
        disabled={loading || uploading}
        className="rounded-lg bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90 disabled:opacity-50"
      >
        {loading ? "Enregistrement..." : store ? "Mettre à jour" : "Créer la boutique"}
      </button>
    </form>
  );
}
