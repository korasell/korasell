"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export function ProductRowActions({
  productId,
  status,
}: {
  productId: string;
  status: "DRAFT" | "PUBLISHED" | "ARCHIVED";
}) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function toggleStatus() {
    setLoading(true);
    const nextStatus = status === "PUBLISHED" ? "DRAFT" : "PUBLISHED";
    await fetch(`/api/products/${productId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: nextStatus }),
    });
    setLoading(false);
    router.refresh();
  }

  async function handleDelete() {
    if (!confirm("Supprimer définitivement ce produit ?")) return;
    setLoading(true);
    await fetch(`/api/products/${productId}`, { method: "DELETE" });
    setLoading(false);
    router.refresh();
  }

  return (
    <div className="flex gap-2">
      <button
        onClick={toggleStatus}
        disabled={loading}
        className="rounded-lg border border-slate-300 px-2.5 py-1 text-xs hover:bg-slate-50 disabled:opacity-50"
      >
        {status === "PUBLISHED" ? "Dépublier" : "Publier"}
      </button>
      <button
        onClick={handleDelete}
        disabled={loading}
        className="rounded-lg border border-red-200 px-2.5 py-1 text-xs text-red-600 hover:bg-red-50 disabled:opacity-50"
      >
        Supprimer
      </button>
    </div>
  );
}
