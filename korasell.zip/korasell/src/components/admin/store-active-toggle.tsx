"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export function StoreActiveToggle({
  storeId,
  isActive,
}: {
  storeId: string;
  isActive: boolean;
}) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function handleToggle() {
    setLoading(true);
    await fetch(`/api/admin/stores/${storeId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isActive: !isActive }),
    });
    setLoading(false);
    router.refresh();
  }

  return (
    <button
      onClick={handleToggle}
      disabled={loading}
      className={`rounded-lg border px-2.5 py-1 text-xs disabled:opacity-50 ${
        isActive
          ? "border-red-200 text-red-600 hover:bg-red-50"
          : "border-green-200 text-green-700 hover:bg-green-50"
      }`}
    >
      {isActive ? "Désactiver" : "Activer"}
    </button>
  );
}
