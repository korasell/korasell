"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

type Status = "DRAFT" | "PUBLISHED" | "ARCHIVED";

export function ProductModerationAction({
  productId,
  status,
}: {
  productId: string;
  status: Status;
}) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function setStatus(nextStatus: Status) {
    setLoading(true);
    await fetch(`/api/admin/products/${productId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: nextStatus }),
    });
    setLoading(false);
    router.refresh();
  }

  if (status === "ARCHIVED") {
    return (
      <button
        onClick={() => setStatus("PUBLISHED")}
        disabled={loading}
        className="rounded-lg border border-green-200 px-2.5 py-1 text-xs text-green-700 hover:bg-green-50 disabled:opacity-50"
      >
        Republier
      </button>
    );
  }

  return (
    <button
      onClick={() => setStatus("ARCHIVED")}
      disabled={loading}
      className="rounded-lg border border-red-200 px-2.5 py-1 text-xs text-red-600 hover:bg-red-50 disabled:opacity-50"
    >
      Archiver
    </button>
  );
}
