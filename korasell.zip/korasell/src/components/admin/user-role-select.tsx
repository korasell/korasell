"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

type Role = "BUYER" | "SELLER" | "ADMIN";

export function UserRoleSelect({
  userId,
  currentRole,
  disabled,
}: {
  userId: string;
  currentRole: Role;
  disabled?: boolean;
}) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function handleChange(role: Role) {
    setLoading(true);
    const res = await fetch(`/api/admin/users/${userId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ role }),
    });
    setLoading(false);
    if (res.ok) router.refresh();
  }

  return (
    <select
      defaultValue={currentRole}
      disabled={disabled || loading}
      onChange={(e) => handleChange(e.target.value as Role)}
      className="rounded-lg border border-slate-300 px-2 py-1 text-xs disabled:opacity-50"
    >
      <option value="BUYER">Acheteur</option>
      <option value="SELLER">Vendeur</option>
      <option value="ADMIN">Admin</option>
    </select>
  );
}
