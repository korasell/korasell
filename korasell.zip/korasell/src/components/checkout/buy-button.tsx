"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

type ProductType = "DIGITAL" | "PHYSICAL" | "SERVICE";

export function BuyButton({
  productId,
  type,
  outOfStock,
}: {
  productId: string;
  type: ProductType;
  outOfStock: boolean;
}) {
  const router = useRouter();
  const [showShipping, setShowShipping] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submitCheckout(formData?: FormData) {
    setError(null);
    setLoading(true);

    const payload: Record<string, unknown> = { productId, quantity: 1 };

    if (formData) {
      payload.shippingName = formData.get("shippingName");
      payload.shippingAddress = formData.get("shippingAddress");
      payload.shippingCity = formData.get("shippingCity");
      payload.shippingPhone = formData.get("shippingPhone");
      payload.quantity = Number(formData.get("quantity")) || 1;
    }

    const res = await fetch("/api/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    const data = await res.json();
    setLoading(false);

    if (!res.ok) {
      if (res.status === 401) {
        router.push("/login");
        return;
      }
      setError(
        typeof data.error === "string" ? data.error : "Une erreur est survenue."
      );
      return;
    }

    window.location.href = data.url;
  }

  if (type === "PHYSICAL" && showShipping) {
    return (
      <form
        action={submitCheckout}
        className="w-full space-y-2 rounded-lg border border-slate-200 p-3"
      >
        <input
          name="shippingName"
          placeholder="Nom complet"
          required
          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
        />
        <input
          name="shippingAddress"
          placeholder="Adresse"
          required
          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
        />
        <div className="flex gap-2">
          <input
            name="shippingCity"
            placeholder="Ville"
            required
            className="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-sm"
          />
          <input
            name="quantity"
            type="number"
            min={1}
            defaultValue={1}
            className="w-20 rounded-lg border border-slate-300 px-3 py-2 text-sm"
          />
        </div>
        <input
          name="shippingPhone"
          placeholder="Téléphone"
          required
          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
        />
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button
          type="submit"
          disabled={loading}
          className="w-full rounded-lg bg-primary py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90 disabled:opacity-50"
        >
          {loading ? "Redirection..." : "Confirmer et payer"}
        </button>
      </form>
    );
  }

  return (
    <div className="flex-1">
      <button
        disabled={outOfStock || loading}
        onClick={() =>
          type === "PHYSICAL" ? setShowShipping(true) : submitCheckout()
        }
        className="w-full rounded-lg bg-primary py-3 text-sm font-medium text-primary-foreground hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-50"
      >
        {outOfStock
          ? "Indisponible"
          : loading
            ? "Redirection..."
            : "Acheter maintenant"}
      </button>
      {error && <p className="mt-2 text-sm text-red-600">{error}</p>}
    </div>
  );
}
