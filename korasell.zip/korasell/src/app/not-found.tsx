import Link from "next/link";

export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center px-4 text-center">
      <p className="text-sm font-medium text-primary">404</p>
      <h1 className="mt-2 text-2xl font-bold">Page introuvable</h1>
      <p className="mt-2 text-sm text-slate-500">
        Le lien que vous avez suivi n&apos;existe pas ou plus.
      </p>
      <Link
        href="/"
        className="mt-6 rounded-lg bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90"
      >
        Retour à l&apos;accueil
      </Link>
    </div>
  );
}
