import { NextResponse } from "next/server";
import Stripe from "stripe";

import { prisma } from "@/lib/prisma";
import { stripe } from "@/lib/stripe";

export async function POST(request: Request) {
  const rawBody = await request.text();
  const signature = request.headers.get("stripe-signature");

  if (!signature || !process.env.STRIPE_WEBHOOK_SECRET) {
    return NextResponse.json({ error: "Signature manquante" }, { status: 400 });
  }

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(
      rawBody,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch {
    return NextResponse.json(
      { error: "Signature Stripe invalide" },
      { status: 400 }
    );
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object as Stripe.Checkout.Session;
    const orderId = session.metadata?.orderId;

    if (orderId) {
      await handleOrderPaid(orderId, session.payment_intent as string);
    }
  }

  return NextResponse.json({ received: true });
}

async function handleOrderPaid(orderId: string, paymentIntentId: string) {
  const order = await prisma.order.findUnique({
    where: { id: orderId },
    include: {
      items: { include: { product: true } },
      payment: true,
      store: { select: { ownerId: true } },
    },
  });

  // Idempotence: si déjà traitée, ne rien refaire
  if (!order || order.status === "PAID" || order.status === "COMPLETED") {
    return;
  }

  await prisma.$transaction(async (tx) => {
    await tx.order.update({
      where: { id: order.id },
      data: { status: "PAID" },
    });

    if (order.payment) {
      await tx.payment.update({
        where: { id: order.payment.id },
        data: { status: "SUCCEEDED", stripePaymentIntentId: paymentIntentId },
      });
    }

    for (const item of order.items) {
      if (item.product.type === "DIGITAL") {
        await tx.orderItem.update({
          where: { id: item.id },
          data: {
            deliveredFileUrl: item.product.digitalFileUrl,
            deliveredLinkUrl: item.product.digitalLinkUrl,
          },
        });
      }

      if (item.product.type === "PHYSICAL") {
        await tx.product.update({
          where: { id: item.productId },
          data: { stockQuantity: { decrement: item.quantity } },
        });
      }
    }

    await tx.notification.create({
      data: {
        userId: order.store.ownerId,
        type: "ORDER",
        title: "Nouvelle commande",
        message: `Vous avez reçu une nouvelle commande de ${order.totalCents.toLocaleString("fr-FR")} ${order.currency}.`,
        link: `/dashboard/vendeur/commandes/${order.id}`,
      },
    });

    await tx.notification.create({
      data: {
        userId: order.buyerId,
        type: "PAYMENT",
        title: "Paiement confirmé",
        message: "Votre commande a été payée avec succès.",
        link: `/dashboard/commandes/${order.id}`,
      },
    });
  });
}
