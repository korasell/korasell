import { NextResponse } from "next/server";

import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { storeSchema } from "@/lib/validations/store";
import { generateUniqueSlug } from "@/lib/slug";

export async function GET() {
  const session = await auth();
  if (!session?.user || !["SELLER", "ADMIN"].includes(session.user.role)) {
    return NextResponse.json({ error: "Non autorisé" }, { status: 403 });
  }

  const stores = await prisma.store.findMany({
    where: { ownerId: session.user.id },
    orderBy: { createdAt: "asc" },
  });

  return NextResponse.json({ stores });
}

export async function POST(request: Request) {
  const session = await auth();
  if (!session?.user || !["SELLER", "ADMIN"].includes(session.user.role)) {
    return NextResponse.json({ error: "Non autorisé" }, { status: 403 });
  }

  const body = await request.json();
  const parsed = storeSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.flatten().fieldErrors },
      { status: 400 }
    );
  }

  const slug = await generateUniqueSlug(parsed.data.name, (candidate) =>
    prisma.store.findUnique({ where: { slug: candidate } })
  );

  const store = await prisma.store.create({
    data: {
      ownerId: session.user.id,
      name: parsed.data.name,
      description: parsed.data.description || null,
      logoUrl: parsed.data.logoUrl || null,
      bannerUrl: parsed.data.bannerUrl || null,
      slug,
    },
  });

  return NextResponse.json({ store }, { status: 201 });
}
