import { NextResponse } from "next/server";

import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { stripe, computeApplicationFee } from "@/lib/stripe";
import { checkoutSchema } from "@/lib/validations/checkout";
import { rateLimit } from "@/lib/rate-limit";

export async function POST(request: Request) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json(
      { error: "Vous devez être connecté pour acheter." },
      { status: 401 }
    );
  }

  const { success } = rateLimit(`checkout:${session.user.id}`, 10, 5 * 60 * 1000);
  if (!success) {
    return NextResponse.json(
      { error: "Trop de tentatives. Réessayez dans quelques minutes." },
      { status: 429 }
    );
  }

  const body = await request.json();
  const parsed = checkoutSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.flatten().fieldErrors },
      { status: 400 }
    );
  }

  const { productId, quantity, shippingName, shippingAddress, shippingCity, shippingPhone } =
    parsed.data;

  const product = await prisma.product.findUnique({
    where: { id: productId, status: "PUBLISHED" },
    include: { store: true },
  });

  if (!product) {
    return NextResponse.json({ error: "Produit introuvable" }, { status: 404 });
  }

  if (!product.store.stripeAccountId || !product.store.payoutsEnabled) {
    return NextResponse.json(
      { error: "Ce vendeur n'a pas encore activé les paiements." },
      { status: 400 }
    );
  }

  if (product.type === "PHYSICAL") {
    if (
      product.stockQuantity === null ||
      product.stockQuantity < quantity
    ) {
      return NextResponse.json(
        { error: "Stock insuffisant." },
        { status: 400 }
      );
    }
    if (!shippingName || !shippingAddress || !shippingCity || !shippingPhone) {
      return NextResponse.json(
        { error: "Les informations de livraison sont requises." },
        { status: 400 }
      );
    }
  }

  const totalCents = product.priceCents * quantity;
  const commissionCents = computeApplicationFee(totalCents);

  const order = await prisma.order.create({
    data: {
      buyerId: session.user.id,
      storeId: product.storeId,
      status: "PENDING",
      totalCents,
      currency: product.currency,
      shippingName: shippingName || null,
      shippingAddress: shippingAddress || null,
      shippingCity: shippingCity || null,
      shippingPhone: shippingPhone || null,
      items: {
        create: [
          {
            productId: product.id,
            quantity,
            unitPriceCents: product.priceCents,
          },
        ],
      },
      payment: {
        create: {
          status: "PENDING",
          amountCents: totalCents,
          currency: product.currency,
          commissionCents,
        },
      },
    },
  });

  const checkoutSession = await stripe.checkout.sessions.create({
    mode: "payment",
    payment_method_types: ["card"],
    line_items: [
      {
        quantity,
        price_data: {
          // XOF est zero-decimal chez Stripe : priceCents est déjà le
          // montant en FCFA, aucune conversion ×100 n'est nécessaire.
          currency: "xof",
          unit_amount: product.priceCents,
          product_data: { name: product.title },
        },
      },
    ],
    payment_intent_data: {
      application_fee_amount: commissionCents,
      transfer_data: { destination: product.store.stripeAccountId },
    },
    metadata: { orderId: order.id },
    success_url: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard/commandes/${order.id}?success=1`,
    cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}/produit/${product.slug}`,
  });

  return NextResponse.json({ url: checkoutSession.url, orderId: order.id });
}
