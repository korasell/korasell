import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";
import { stripe } from "@/lib/stripe";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const storeId = searchParams.get("storeId");

  if (!storeId) {
    return NextResponse.redirect(
      `${process.env.NEXT_PUBLIC_APP_URL}/dashboard/vendeur/boutique`
    );
  }

  const store = await prisma.store.findUnique({ where: { id: storeId } });

  if (store?.stripeAccountId) {
    const account = await stripe.accounts.retrieve(store.stripeAccountId);
    await prisma.store.update({
      where: { id: storeId },
      data: { payoutsEnabled: !!account.charges_enabled },
    });
  }

  return NextResponse.redirect(
    `${process.env.NEXT_PUBLIC_APP_URL}/dashboard/vendeur/boutique?stripe=1`
  );
}
