import { NextResponse } from "next/server";

import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { stripe } from "@/lib/stripe";

export async function POST(request: Request) {
  const session = await auth();
  if (!session?.user || !["SELLER", "ADMIN"].includes(session.user.role)) {
    return NextResponse.json({ error: "Non autorisé" }, { status: 403 });
  }

  const { storeId } = await request.json();

  const store = await prisma.store.findUnique({ where: { id: storeId } });
  if (!store || store.ownerId !== session.user.id) {
    return NextResponse.json(
      { error: "Boutique introuvable ou non autorisée" },
      { status: 403 }
    );
  }

  let accountId = store.stripeAccountId;

  if (!accountId) {
    const account = await stripe.accounts.create({
      type: "express",
      email: session.user.email ?? undefined,
      business_type: "individual",
      capabilities: {
        card_payments: { requested: true },
        transfers: { requested: true },
      },
    });

    accountId = account.id;

    await prisma.store.update({
      where: { id: store.id },
      data: { stripeAccountId: accountId },
    });
  }

  const accountLink = await stripe.accountLinks.create({
    account: accountId,
    refresh_url: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard/vendeur/boutique`,
    return_url: `${process.env.NEXT_PUBLIC_APP_URL}/api/stripe/connect/callback?storeId=${store.id}`,
    type: "account_onboarding",
  });

  return NextResponse.json({ url: accountLink.url });
}
