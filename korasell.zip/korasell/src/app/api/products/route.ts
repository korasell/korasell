import { NextResponse } from "next/server";

import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { productSchema } from "@/lib/validations/product";
import { generateUniqueSlug } from "@/lib/slug";

export async function GET(request: Request) {
  const session = await auth();
  if (!session?.user || !["SELLER", "ADMIN"].includes(session.user.role)) {
    return NextResponse.json({ error: "Non autorisé" }, { status: 403 });
  }

  const { searchParams } = new URL(request.url);
  const storeId = searchParams.get("storeId");

  const products = await prisma.product.findMany({
    where: {
      store: { ownerId: session.user.id },
      ...(storeId ? { storeId } : {}),
    },
    orderBy: { createdAt: "desc" },
    include: { images: { orderBy: { position: "asc" }, take: 1 } },
  });

  return NextResponse.json({ products });
}

export async function POST(request: Request) {
  const session = await auth();
  if (!session?.user || !["SELLER", "ADMIN"].includes(session.user.role)) {
    return NextResponse.json({ error: "Non autorisé" }, { status: 403 });
  }

  const body = await request.json();
  const { storeId, ...productData } = body;

  if (!storeId) {
    return NextResponse.json(
      { error: "storeId est requis" },
      { status: 400 }
    );
  }

  const store = await prisma.store.findUnique({ where: { id: storeId } });
  if (!store || store.ownerId !== session.user.id) {
    return NextResponse.json(
      { error: "Boutique introuvable ou non autorisée" },
      { status: 403 }
    );
  }

  const parsed = productSchema.safeParse(productData);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.flatten().fieldErrors },
      { status: 400 }
    );
  }

  const slug = await generateUniqueSlug(parsed.data.title, (candidate) =>
    prisma.product.findUnique({ where: { slug: candidate } })
  );

  const { images, ...rest } = parsed.data;

  const product = await prisma.product.create({
    data: {
      ...rest,
      description: rest.description || null,
      digitalFileUrl: rest.digitalFileUrl || null,
      digitalLinkUrl: rest.digitalLinkUrl || null,
      serviceLocation: rest.serviceLocation || null,
      slug,
      storeId,
      images: {
        create: images.map((url, position) => ({ url, position })),
      },
    },
    include: { images: true },
  });

  return NextResponse.json({ product }, { status: 201 });
}
