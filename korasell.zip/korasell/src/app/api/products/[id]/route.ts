import { NextResponse } from "next/server";

import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { productSchema } from "@/lib/validations/product";

async function getOwnedProduct(productId: string, userId: string) {
  const product = await prisma.product.findUnique({
    where: { id: productId },
    include: { store: true },
  });
  if (!product || product.store.ownerId !== userId) return null;
  return product;
}

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Non autorisé" }, { status: 403 });
  }

  const { id } = await params;
  const product = await prisma.product.findUnique({
    where: { id },
    include: { images: { orderBy: { position: "asc" } } },
  });

  if (!product) {
    return NextResponse.json({ error: "Produit introuvable" }, { status: 404 });
  }

  return NextResponse.json({ product });
}

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Non autorisé" }, { status: 403 });
  }

  const { id } = await params;
  const existing = await getOwnedProduct(id, session.user.id);
  if (!existing) {
    return NextResponse.json(
      { error: "Produit introuvable ou non autorisé" },
      { status: 403 }
    );
  }

  const body = await request.json();

  // Mise à jour rapide du statut uniquement (publier/dépublier)
  if (body.status && Object.keys(body).length === 1) {
    const product = await prisma.product.update({
      where: { id },
      data: { status: body.status },
    });
    return NextResponse.json({ product });
  }

  const parsed = productSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.flatten().fieldErrors },
      { status: 400 }
    );
  }

  const { images, ...rest } = parsed.data;

  const product = await prisma.product.update({
    where: { id },
    data: {
      ...rest,
      description: rest.description || null,
      digitalFileUrl: rest.digitalFileUrl || null,
      digitalLinkUrl: rest.digitalLinkUrl || null,
      serviceLocation: rest.serviceLocation || null,
      images: {
        deleteMany: {},
        create: images.map((url, position) => ({ url, position })),
      },
    },
    include: { images: true },
  });

  return NextResponse.json({ product });
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Non autorisé" }, { status: 403 });
  }

  const { id } = await params;
  const existing = await getOwnedProduct(id, session.user.id);
  if (!existing) {
    return NextResponse.json(
      { error: "Produit introuvable ou non autorisé" },
      { status: 403 }
    );
  }

  await prisma.product.delete({ where: { id } });
  return NextResponse.json({ success: true });
}
