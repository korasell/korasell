import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { formatPrice } from "@/lib/utils";
import { RevenueChart } from "@/components/dashboard/revenue-chart";

const STATUS_LABELS: Record<string, string> = {
  PENDING: "En attente",
  PAID: "Payée",
  PROCESSING: "En préparation",
  SHIPPED: "Expédiée",
  DELIVERED: "Livrée",
  COMPLETED: "Terminée",
  CANCELLED: "Annulée",
  REFUNDED: "Remboursée",
};

export default async function VendeurStatistiquesPage() {
  const session = await auth();
  const store = await prisma.store.findFirst({
    where: { ownerId: session!.user.id },
    orderBy: { createdAt: "asc" },
  });

  if (!store) {
    return (
      <div>
        <h1 className="text-2xl font-bold">Statistiques</h1>
        <p className="mt-2 text-sm text-slate-500">
          Créez d&apos;abord votre boutique pour voir vos statistiques.
        </p>
      </div>
    );
  }

  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 29);
  thirtyDaysAgo.setHours(0, 0, 0, 0);

  const [payments, orderItems, statusCounts, totalRevenue] = await Promise.all([
    prisma.payment.findMany({
      where: {
        status: "SUCCEEDED",
        order: { storeId: store.id, createdAt: { gte: thirtyDaysAgo } },
      },
      select: { amountCents: true, createdAt: true },
    }),
    prisma.orderItem.findMany({
      where: {
        order: { storeId: store.id, status: { notIn: ["PENDING", "CANCELLED"] } },
      },
      select: {
        quantity: true,
        unitPriceCents: true,
        product: { select: { id: true, title: true } },
      },
    }),
    prisma.order.groupBy({
      by: ["status"],
      where: { storeId: store.id },
      _count: { _all: true },
    }),
    prisma.payment.aggregate({
      where: { status: "SUCCEEDED", order: { storeId: store.id } },
      _sum: { amountCents: true, commissionCents: true },
    }),
  ]);

  // Revenu par jour sur les 30 derniers jours
  const revenueByDay = new Map<string, number>();
  for (let i = 0; i < 30; i++) {
    const d = new Date(thirtyDaysAgo);
    d.setDate(d.getDate() + i);
    revenueByDay.set(d.toISOString().slice(0, 10), 0);
  }
  for (const payment of payments) {
    const key = payment.createdAt.toISOString().slice(0, 10);
    revenueByDay.set(key, (revenueByDay.get(key) ?? 0) + payment.amountCents);
  }
  const chartData = Array.from(revenueByDay.entries()).map(([date, revenue]) => ({
    date: date.slice(5), // MM-JJ
    revenue,
  }));

  // Top produits par revenu
  const productRevenue = new Map<string, { title: string; revenue: number; sold: number }>();
  for (const item of orderItems) {
    const key = item.product.id;
    const existing = productRevenue.get(key) ?? {
      title: item.product.title,
      revenue: 0,
      sold: 0,
    };
    existing.revenue += item.quantity * item.unitPriceCents;
    existing.sold += item.quantity;
    productRevenue.set(key, existing);
  }
  const topProducts = Array.from(productRevenue.values())
    .sort((a, b) => b.revenue - a.revenue)
    .slice(0, 5);

  return (
    <div>
      <h1 className="text-2xl font-bold">Statistiques</h1>

      <div className="mt-4 grid grid-cols-2 gap-4">
        <div className="rounded-lg border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Chiffre d&apos;affaires total</p>
          <p className="text-2xl font-bold">
            {formatPrice(totalRevenue._sum.amountCents ?? 0)}
          </p>
        </div>
        <div className="rounded-lg border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Commissions prélevées</p>
          <p className="text-2xl font-bold">
            {formatPrice(totalRevenue._sum.commissionCents ?? 0)}
          </p>
        </div>
      </div>

      <div className="mt-6 rounded-lg border border-slate-200 bg-white p-4">
        <p className="mb-2 text-sm font-medium">Revenus (30 derniers jours)</p>
        <RevenueChart data={chartData} />
      </div>

      <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2">
        <div className="rounded-lg border border-slate-200 bg-white p-4">
          <p className="mb-3 text-sm font-medium">Produits les plus vendus</p>
          <div className="space-y-2">
            {topProducts.map((p) => (
              <div key={p.title} className="flex justify-between text-sm">
                <span className="truncate">{p.title}</span>
                <span className="shrink-0 font-medium">
                  {formatPrice(p.revenue)} ({p.sold} vendus)
                </span>
              </div>
            ))}
            {topProducts.length === 0 && (
              <p className="text-sm text-slate-500">Aucune vente pour le moment.</p>
            )}
          </div>
        </div>

        <div className="rounded-lg border border-slate-200 bg-white p-4">
          <p className="mb-3 text-sm font-medium">Commandes par statut</p>
          <div className="space-y-2">
            {statusCounts.map((s) => (
              <div key={s.status} className="flex justify-between text-sm">
                <span>{STATUS_LABELS[s.status]}</span>
                <span className="font-medium">{s._count._all}</span>
              </div>
            ))}
            {statusCounts.length === 0 && (
              <p className="text-sm text-slate-500">Aucune commande pour le moment.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
