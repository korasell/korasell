import { notFound } from "next/navigation";

import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { formatPrice } from "@/lib/utils";
import { OrderStatusSelect } from "@/components/dashboard/order-status-select";

const STATUS_LABELS: Record<string, string> = {
  PENDING: "En attente de paiement",
  PAID: "Payée",
  PROCESSING: "En préparation",
  SHIPPED: "Expédiée",
  DELIVERED: "Livrée",
  COMPLETED: "Terminée",
  CANCELLED: "Annulée",
  REFUNDED: "Remboursée",
};

export default async function VendeurCommandeDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const session = await auth();

  const order = await prisma.order.findUnique({
    where: { id },
    include: {
      store: true,
      buyer: { select: { name: true, email: true } },
      items: { include: { product: true } },
    },
  });

  if (!order || order.store.ownerId !== session!.user.id) {
    notFound();
  }

  const canUpdateStatus = order.status !== "PENDING" && order.status !== "CANCELLED";

  return (
    <div>
      <h1 className="text-2xl font-bold">Commande</h1>
      <p className="mt-1 text-sm text-slate-500">
        {order.buyer.name ?? order.buyer.email} · {STATUS_LABELS[order.status]}
      </p>

      {order.shippingAddress && (
        <div className="mt-4 rounded-lg border border-slate-200 bg-white p-4">
          <p className="text-sm font-medium">Livraison</p>
          <p className="text-sm text-slate-600">
            {order.shippingName} · {order.shippingAddress},{" "}
            {order.shippingCity} · {order.shippingPhone}
          </p>
        </div>
      )}

      <div className="mt-4 space-y-3">
        {order.items.map((item) => (
          <div
            key={item.id}
            className="rounded-lg border border-slate-200 bg-white p-4"
          >
            <p className="font-medium">{item.product.title}</p>
            <p className="text-sm text-slate-500">
              Quantité : {item.quantity} ·{" "}
              {formatPrice(item.unitPriceCents * item.quantity, order.currency)}
            </p>
          </div>
        ))}
      </div>

      {canUpdateStatus && (
        <div className="mt-6">
          <p className="mb-1 text-sm font-medium">Statut de la commande</p>
          <OrderStatusSelect orderId={order.id} currentStatus={order.status} />
        </div>
      )}

      <div className="mt-6 rounded-lg border border-slate-200 bg-white p-4">
        <p className="text-sm font-medium">Total</p>
        <p className="text-lg font-bold">
          {formatPrice(order.totalCents, order.currency)}
        </p>
      </div>
    </div>
  );
}
