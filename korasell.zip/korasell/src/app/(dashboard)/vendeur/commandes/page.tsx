import Link from "next/link";

import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { formatPrice } from "@/lib/utils";

const STATUS_LABELS: Record<string, string> = {
  PENDING: "En attente de paiement",
  PAID: "Payée",
  PROCESSING: "En préparation",
  SHIPPED: "Expédiée",
  DELIVERED: "Livrée",
  COMPLETED: "Terminée",
  CANCELLED: "Annulée",
  REFUNDED: "Remboursée",
};

export default async function VendeurCommandesPage() {
  const session = await auth();

  const orders = await prisma.order.findMany({
    where: { store: { ownerId: session!.user.id } },
    orderBy: { createdAt: "desc" },
    include: {
      buyer: { select: { name: true, email: true } },
      items: { include: { product: { select: { title: true } } } },
    },
  });

  return (
    <div>
      <h1 className="text-2xl font-bold">Commandes</h1>

      <div className="mt-6 divide-y divide-slate-200 rounded-lg border border-slate-200 bg-white">
        {orders.map((order) => (
          <Link
            key={order.id}
            href={`/dashboard/vendeur/commandes/${order.id}`}
            className="flex items-center justify-between px-4 py-3 hover:bg-slate-50"
          >
            <div>
              <p className="text-sm font-medium">
                {order.items.map((i) => i.product.title).join(", ")}
              </p>
              <p className="text-xs text-slate-500">
                {order.buyer.name ?? order.buyer.email} ·{" "}
                {STATUS_LABELS[order.status]}
              </p>
            </div>
            <p className="text-sm font-semibold">
              {formatPrice(order.totalCents, order.currency)}
            </p>
          </Link>
        ))}

        {orders.length === 0 && (
          <p className="px-4 py-6 text-sm text-slate-500">
            Aucune commande reçue pour le moment.
          </p>
        )}
      </div>
    </div>
  );
}
