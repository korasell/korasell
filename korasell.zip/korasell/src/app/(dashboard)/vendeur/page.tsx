import Link from "next/link";

import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";

export default async function VendeurOverviewPage() {
  const session = await auth();
  const store = await prisma.store.findFirst({
    where: { ownerId: session!.user.id },
    orderBy: { createdAt: "asc" },
  });

  if (!store) {
    return (
      <div className="max-w-lg">
        <h1 className="text-2xl font-bold">Bienvenue sur Korasell</h1>
        <p className="mt-2 text-sm text-slate-600">
          Vous n&apos;avez pas encore de boutique. Créez-en une pour commencer
          à publier vos produits.
        </p>
        <Link
          href="/dashboard/vendeur/boutique"
          className="mt-6 inline-block rounded-lg bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90"
        >
          Créer ma boutique
        </Link>
      </div>
    );
  }

  const [productCount, publishedCount, orderCount] = await Promise.all([
    prisma.product.count({ where: { storeId: store.id } }),
    prisma.product.count({
      where: { storeId: store.id, status: "PUBLISHED" },
    }),
    prisma.order.count({ where: { storeId: store.id } }),
  ]);

  return (
    <div>
      <h1 className="text-2xl font-bold">{store.name}</h1>
      <p className="text-sm text-slate-500">
        {process.env.NEXT_PUBLIC_APP_URL}/boutique/{store.slug}
      </p>

      <div className="mt-6 grid grid-cols-3 gap-4">
        <div className="rounded-lg border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Produits</p>
          <p className="text-2xl font-bold">{productCount}</p>
        </div>
        <div className="rounded-lg border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Publiés</p>
          <p className="text-2xl font-bold">{publishedCount}</p>
        </div>
        <div className="rounded-lg border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Commandes</p>
          <p className="text-2xl font-bold">{orderCount}</p>
        </div>
      </div>

      <Link
        href="/dashboard/vendeur/produits/nouveau"
        className="mt-6 inline-block rounded-lg bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90"
      >
        + Ajouter un produit
      </Link>
    </div>
  );
}
