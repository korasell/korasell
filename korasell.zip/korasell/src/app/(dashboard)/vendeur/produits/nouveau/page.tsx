import { redirect } from "next/navigation";

import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { ProductForm } from "@/components/dashboard/product-form";

export default async function NouveauProduitPage() {
  const session = await auth();
  const store = await prisma.store.findFirst({
    where: { ownerId: session!.user.id },
    orderBy: { createdAt: "asc" },
  });

  if (!store) {
    redirect("/dashboard/vendeur/boutique");
  }

  return (
    <div>
      <h1 className="text-2xl font-bold">Nouveau produit</h1>
      <p className="mt-1 text-sm text-slate-500">
        Le produit sera créé en brouillon. Publiez-le depuis la liste des
        produits une fois prêt.
      </p>

      <div className="mt-6">
        <ProductForm storeId={store.id} product={null} />
      </div>
    </div>
  );
}
