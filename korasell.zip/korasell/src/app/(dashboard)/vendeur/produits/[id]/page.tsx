import { notFound } from "next/navigation";

import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { ProductForm } from "@/components/dashboard/product-form";

export default async function EditProduitPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const session = await auth();

  const product = await prisma.product.findUnique({
    where: { id },
    include: { images: { orderBy: { position: "asc" } }, store: true },
  });

  if (!product || product.store.ownerId !== session!.user.id) {
    notFound();
  }

  return (
    <div>
      <h1 className="text-2xl font-bold">Modifier le produit</h1>

      <div className="mt-6">
        <ProductForm storeId={product.storeId} product={product} />
      </div>
    </div>
  );
}
