import Link from "next/link";

import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { formatPrice } from "@/lib/utils";
import { ProductRowActions } from "@/components/dashboard/product-row-actions";

const STATUS_LABELS: Record<string, string> = {
  DRAFT: "Brouillon",
  PUBLISHED: "Publié",
  ARCHIVED: "Archivé",
};

export default async function ProduitsPage() {
  const session = await auth();

  const products = await prisma.product.findMany({
    where: { store: { ownerId: session!.user.id } },
    orderBy: { createdAt: "desc" },
    include: { images: { orderBy: { position: "asc" }, take: 1 } },
  });

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Produits</h1>
        <Link
          href="/dashboard/vendeur/produits/nouveau"
          className="rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90"
        >
          + Ajouter un produit
        </Link>
      </div>

      <div className="mt-6 divide-y divide-slate-200 rounded-lg border border-slate-200 bg-white">
        {products.map((product) => (
          <div
            key={product.id}
            className="flex items-center gap-4 px-4 py-3"
          >
            <div className="h-12 w-12 shrink-0 overflow-hidden rounded-md bg-slate-100">
              {product.images[0] && (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={product.images[0].url}
                  alt=""
                  className="h-full w-full object-cover"
                />
              )}
            </div>

            <div className="min-w-0 flex-1">
              <Link
                href={`/dashboard/vendeur/produits/${product.id}`}
                className="truncate text-sm font-medium hover:underline"
              >
                {product.title}
              </Link>
              <p className="text-xs text-slate-500">
                {formatPrice(product.priceCents, product.currency)} ·{" "}
                {STATUS_LABELS[product.status]}
              </p>
            </div>

            <ProductRowActions productId={product.id} status={product.status} />
          </div>
        ))}

        {products.length === 0 && (
          <p className="px-4 py-6 text-sm text-slate-500">
            Aucun produit pour le moment.
          </p>
        )}
      </div>
    </div>
  );
}
