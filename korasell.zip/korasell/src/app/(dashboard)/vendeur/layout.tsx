import Link from "next/link";
import { redirect } from "next/navigation";

import { auth } from "@/auth";
import { NotificationBell } from "@/components/notifications/notification-bell";

const NAV_ITEMS = [
  { href: "/dashboard/vendeur", label: "Vue d'ensemble" },
  { href: "/dashboard/vendeur/boutique", label: "Ma boutique" },
  { href: "/dashboard/vendeur/produits", label: "Produits" },
  { href: "/dashboard/vendeur/commandes", label: "Commandes" },
  { href: "/dashboard/vendeur/statistiques", label: "Statistiques" },
];

export default async function VendeurLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await auth();

  if (!session?.user || !["SELLER", "ADMIN"].includes(session.user.role)) {
    redirect("/login");
  }

  return (
    <div className="mx-auto flex min-h-screen max-w-6xl">
      <aside className="w-56 shrink-0 border-r border-slate-200 px-4 py-8">
        <Link href="/" className="mb-8 block text-lg font-bold text-primary">
          Korasell
        </Link>
        <nav className="space-y-1">
          {NAV_ITEMS.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="block rounded-lg px-3 py-2 text-sm text-slate-700 hover:bg-slate-100"
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </aside>

      <main className="flex-1 px-6 py-8">
        <div className="mb-4 flex justify-end">
          <NotificationBell />
        </div>
        {children}
      </main>
    </div>
  );
}
