import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { StoreForm } from "@/components/dashboard/store-form";
import { StripeConnectButton } from "@/components/dashboard/stripe-connect-button";

export default async function VendeurBoutiquePage() {
  const session = await auth();
  const store = await prisma.store.findFirst({
    where: { ownerId: session!.user.id },
    orderBy: { createdAt: "asc" },
  });

  return (
    <div>
      <h1 className="text-2xl font-bold">
        {store ? "Ma boutique" : "Créer ma boutique"}
      </h1>
      <p className="mt-1 text-sm text-slate-500">
        {store
          ? "Modifiez les informations publiques de votre boutique."
          : "Cette boutique aura un lien public unique que vous pourrez partager."}
      </p>

      <div className="mt-6">
        <StoreForm store={store} />
      </div>

      {store && (
        <div className="mt-10 max-w-lg border-t border-slate-200 pt-6">
          <h2 className="text-lg font-semibold">Paiements</h2>
          <p className="mt-1 text-sm text-slate-500">
            Connectez un compte Stripe pour recevoir directement le paiement
            de vos ventes (commission Korasell de 10% prélevée
            automatiquement).
          </p>
          <div className="mt-3">
            <StripeConnectButton
              storeId={store.id}
              payoutsEnabled={store.payoutsEnabled}
            />
          </div>
        </div>
      )}
    </div>
  );
}
