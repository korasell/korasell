import Link from "next/link";

import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { formatPrice } from "@/lib/utils";

const STATUS_LABELS: Record<string, string> = {
  PENDING: "En attente de paiement",
  PAID: "Payée",
  PROCESSING: "En préparation",
  SHIPPED: "Expédiée",
  DELIVERED: "Livrée",
  COMPLETED: "Terminée",
  CANCELLED: "Annulée",
  REFUNDED: "Remboursée",
};

export default async function CommandesPage() {
  const session = await auth();

  const orders = await prisma.order.findMany({
    where: { buyerId: session!.user.id },
    orderBy: { createdAt: "desc" },
    include: {
      store: { select: { name: true } },
      items: { include: { product: { select: { title: true } } } },
    },
  });

  return (
    <div>
      <h1 className="text-2xl font-bold">Mes commandes</h1>

      <div className="mt-6 divide-y divide-slate-200 rounded-lg border border-slate-200 bg-white">
        {orders.map((order) => (
          <Link
            key={order.id}
            href={`/dashboard/commandes/${order.id}`}
            className="flex items-center justify-between px-4 py-3 hover:bg-slate-50"
          >
            <div>
              <p className="text-sm font-medium">
                {order.items.map((i) => i.product.title).join(", ")}
              </p>
              <p className="text-xs text-slate-500">
                {order.store.name} · {STATUS_LABELS[order.status]}
              </p>
            </div>
            <p className="text-sm font-semibold">
              {formatPrice(order.totalCents, order.currency)}
            </p>
          </Link>
        ))}

        {orders.length === 0 && (
          <p className="px-4 py-6 text-sm text-slate-500">
            Vous n&apos;avez pas encore de commande.
          </p>
        )}
      </div>
    </div>
  );
}
