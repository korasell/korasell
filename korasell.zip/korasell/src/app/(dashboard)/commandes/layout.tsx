import Link from "next/link";

import { NotificationBell } from "@/components/notifications/notification-bell";

export default function CommandesLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <div className="flex items-center justify-between">
        <Link href="/" className="text-sm text-slate-500 hover:underline">
          ← Retour à Korasell
        </Link>
        <NotificationBell />
      </div>
      <div className="mt-4">{children}</div>
    </div>
  );
}
