import { notFound } from "next/navigation";

import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { formatPrice } from "@/lib/utils";

const STATUS_LABELS: Record<string, string> = {
  PENDING: "En attente de paiement",
  PAID: "Payée",
  PROCESSING: "En préparation",
  SHIPPED: "Expédiée",
  DELIVERED: "Livrée",
  COMPLETED: "Terminée",
  CANCELLED: "Annulée",
  REFUNDED: "Remboursée",
};

export default async function CommandeDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const session = await auth();

  const order = await prisma.order.findUnique({
    where: { id },
    include: {
      store: { select: { name: true, slug: true } },
      items: { include: { product: true } },
    },
  });

  if (!order || order.buyerId !== session!.user.id) {
    notFound();
  }

  const isPaid = order.status !== "PENDING" && order.status !== "CANCELLED";

  return (
    <div>
      <h1 className="text-2xl font-bold">Commande</h1>
      <p className="mt-1 text-sm text-slate-500">
        {order.store.name} · {STATUS_LABELS[order.status]}
      </p>

      <div className="mt-6 space-y-4">
        {order.items.map((item) => (
          <div
            key={item.id}
            className="rounded-lg border border-slate-200 bg-white p-4"
          >
            <p className="font-medium">{item.product.title}</p>
            <p className="text-sm text-slate-500">
              Quantité : {item.quantity} ·{" "}
              {formatPrice(item.unitPriceCents * item.quantity, order.currency)}
            </p>

            {isPaid && item.product.type === "DIGITAL" && (
              <div className="mt-3 rounded-lg bg-slate-50 p-3">
                <p className="mb-2 text-sm font-medium">Votre accès</p>
                {item.deliveredFileUrl && (
                  <a
                    href={item.deliveredFileUrl}
                    className="block text-sm text-primary underline"
                  >
                    Télécharger le fichier
                  </a>
                )}
                {item.deliveredLinkUrl && (
                  <a
                    href={item.deliveredLinkUrl}
                    className="block text-sm text-primary underline"
                  >
                    Accéder au lien
                  </a>
                )}
                {!item.deliveredFileUrl && !item.deliveredLinkUrl && (
                  <p className="text-sm text-slate-500">
                    La livraison est en cours de traitement.
                  </p>
                )}
              </div>
            )}

            {isPaid && item.product.type === "SERVICE" && (
              <p className="mt-2 text-sm text-slate-600">
                Le vendeur vous contactera pour planifier votre service.
              </p>
            )}
          </div>
        ))}
      </div>

      {order.status === "PENDING" && (
        <p className="mt-4 text-sm text-amber-600">
          En attente de confirmation du paiement...
        </p>
      )}

      <div className="mt-6 rounded-lg border border-slate-200 bg-white p-4">
        <p className="text-sm font-medium">Total payé</p>
        <p className="text-lg font-bold">
          {formatPrice(order.totalCents, order.currency)}
        </p>
      </div>
    </div>
  );
}
