import { prisma } from "@/lib/prisma";
import { formatPrice } from "@/lib/utils";

export default async function AdminOverviewPage() {
  const [userCount, storeCount, productCount, orderCount, revenue] =
    await Promise.all([
      prisma.user.count(),
      prisma.store.count(),
      prisma.product.count({ where: { status: "PUBLISHED" } }),
      prisma.order.count(),
      prisma.payment.aggregate({
        where: { status: "SUCCEEDED" },
        _sum: { amountCents: true, commissionCents: true },
      }),
    ]);

  const stats = [
    { label: "Utilisateurs", value: userCount },
    { label: "Boutiques", value: storeCount },
    { label: "Produits publiés", value: productCount },
    { label: "Commandes", value: orderCount },
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold">Vue d&apos;ensemble</h1>

      <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-4">
        {stats.map((stat) => (
          <div
            key={stat.label}
            className="rounded-lg border border-slate-200 bg-white p-4"
          >
            <p className="text-xs text-slate-500">{stat.label}</p>
            <p className="text-2xl font-bold">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="mt-4 grid grid-cols-2 gap-4">
        <div className="rounded-lg border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Chiffre d&apos;affaires total</p>
          <p className="text-2xl font-bold">
            {formatPrice(revenue._sum.amountCents ?? 0)}
          </p>
        </div>
        <div className="rounded-lg border border-slate-200 bg-white p-4">
          <p className="text-xs text-slate-500">Commissions Korasell</p>
          <p className="text-2xl font-bold">
            {formatPrice(revenue._sum.commissionCents ?? 0)}
          </p>
        </div>
      </div>
    </div>
  );
}
