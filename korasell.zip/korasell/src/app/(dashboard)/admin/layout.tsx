import Link from "next/link";
import { redirect } from "next/navigation";

import { auth } from "@/auth";
import { NotificationBell } from "@/components/notifications/notification-bell";

const NAV_ITEMS = [
  { href: "/dashboard/admin", label: "Vue d'ensemble" },
  { href: "/dashboard/admin/utilisateurs", label: "Utilisateurs" },
  { href: "/dashboard/admin/boutiques", label: "Boutiques" },
  { href: "/dashboard/admin/produits", label: "Produits" },
];

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await auth();

  if (!session?.user || session.user.role !== "ADMIN") {
    redirect("/login");
  }

  return (
    <div className="mx-auto flex min-h-screen max-w-6xl">
      <aside className="w-56 shrink-0 border-r border-slate-200 px-4 py-8">
        <Link href="/" className="mb-8 block text-lg font-bold text-primary">
          Korasell <span className="text-xs font-normal text-slate-400">Admin</span>
        </Link>
        <nav className="space-y-1">
          {NAV_ITEMS.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="block rounded-lg px-3 py-2 text-sm text-slate-700 hover:bg-slate-100"
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </aside>

      <main className="flex-1 px-6 py-8">
        <div className="mb-4 flex justify-end">
          <NotificationBell />
        </div>
        {children}
      </main>
    </div>
  );
}
