import Link from "next/link";

import { prisma } from "@/lib/prisma";
import { StoreActiveToggle } from "@/components/admin/store-active-toggle";

export default async function AdminBoutiquesPage() {
  const stores = await prisma.store.findMany({
    orderBy: { createdAt: "desc" },
    include: {
      owner: { select: { name: true, email: true } },
      _count: { select: { products: true, orders: true } },
    },
  });

  return (
    <div>
      <h1 className="text-2xl font-bold">Boutiques</h1>
      <p className="mt-1 text-sm text-slate-500">{stores.length} boutiques</p>

      <div className="mt-6 overflow-hidden rounded-lg border border-slate-200 bg-white">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-left text-xs text-slate-500">
            <tr>
              <th className="px-4 py-2">Boutique</th>
              <th className="px-4 py-2">Propriétaire</th>
              <th className="px-4 py-2">Produits</th>
              <th className="px-4 py-2">Commandes</th>
              <th className="px-4 py-2">Statut</th>
              <th className="px-4 py-2"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {stores.map((store) => (
              <tr key={store.id}>
                <td className="px-4 py-2">
                  <Link
                    href={`/boutique/${store.slug}`}
                    target="_blank"
                    className="font-medium hover:underline"
                  >
                    {store.name}
                  </Link>
                </td>
                <td className="px-4 py-2 text-slate-600">
                  {store.owner.email}
                </td>
                <td className="px-4 py-2">{store._count.products}</td>
                <td className="px-4 py-2">{store._count.orders}</td>
                <td className="px-4 py-2">
                  <span
                    className={`rounded-full px-2 py-0.5 text-xs ${
                      store.isActive
                        ? "bg-green-100 text-green-700"
                        : "bg-red-100 text-red-700"
                    }`}
                  >
                    {store.isActive ? "Active" : "Désactivée"}
                  </span>
                </td>
                <td className="px-4 py-2">
                  <StoreActiveToggle
                    storeId={store.id}
                    isActive={store.isActive}
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
