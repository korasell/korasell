import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { UserRoleSelect } from "@/components/admin/user-role-select";

const ROLE_LABELS: Record<string, string> = {
  BUYER: "Acheteur",
  SELLER: "Vendeur",
  ADMIN: "Admin",
};

export default async function AdminUtilisateursPage() {
  const session = await auth();

  const users = await prisma.user.findMany({
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
      createdAt: true,
      _count: { select: { stores: true, orders: true } },
    },
  });

  return (
    <div>
      <h1 className="text-2xl font-bold">Utilisateurs</h1>
      <p className="mt-1 text-sm text-slate-500">{users.length} comptes</p>

      <div className="mt-6 overflow-hidden rounded-lg border border-slate-200 bg-white">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-left text-xs text-slate-500">
            <tr>
              <th className="px-4 py-2">Nom</th>
              <th className="px-4 py-2">E-mail</th>
              <th className="px-4 py-2">Boutiques</th>
              <th className="px-4 py-2">Commandes</th>
              <th className="px-4 py-2">Rôle</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {users.map((user) => (
              <tr key={user.id}>
                <td className="px-4 py-2">{user.name ?? "—"}</td>
                <td className="px-4 py-2 text-slate-600">{user.email}</td>
                <td className="px-4 py-2">{user._count.stores}</td>
                <td className="px-4 py-2">{user._count.orders}</td>
                <td className="px-4 py-2">
                  <UserRoleSelect
                    userId={user.id}
                    currentRole={user.role}
                    disabled={user.id === session?.user.id}
                  />
                  {user.id === session?.user.id && (
                    <span className="ml-2 text-xs text-slate-400">
                      ({ROLE_LABELS[user.role]}, vous)
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
