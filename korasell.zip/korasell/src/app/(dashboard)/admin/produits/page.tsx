import { prisma } from "@/lib/prisma";
import { formatPrice } from "@/lib/utils";
import { ProductModerationAction } from "@/components/admin/product-moderation-action";

const STATUS_LABELS: Record<string, string> = {
  DRAFT: "Brouillon",
  PUBLISHED: "Publié",
  ARCHIVED: "Archivé",
};

export default async function AdminProduitsPage() {
  const products = await prisma.product.findMany({
    orderBy: { createdAt: "desc" },
    include: {
      store: { select: { name: true, slug: true } },
      images: { orderBy: { position: "asc" }, take: 1 },
    },
  });

  return (
    <div>
      <h1 className="text-2xl font-bold">Produits</h1>
      <p className="mt-1 text-sm text-slate-500">
        {products.length} produits sur la plateforme
      </p>

      <div className="mt-6 divide-y divide-slate-200 rounded-lg border border-slate-200 bg-white">
        {products.map((product) => (
          <div key={product.id} className="flex items-center gap-4 px-4 py-3">
            <div className="h-12 w-12 shrink-0 overflow-hidden rounded-md bg-slate-100">
              {product.images[0] && (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={product.images[0].url}
                  alt=""
                  className="h-full w-full object-cover"
                />
              )}
            </div>

            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium">{product.title}</p>
              <p className="text-xs text-slate-500">
                {product.store.name} ·{" "}
                {formatPrice(product.priceCents, product.currency)} ·{" "}
                {STATUS_LABELS[product.status]}
              </p>
            </div>

            <ProductModerationAction
              productId={product.id}
              status={product.status}
            />
          </div>
        ))}

        {products.length === 0 && (
          <p className="px-4 py-6 text-sm text-slate-500">
            Aucun produit sur la plateforme.
          </p>
        )}
      </div>
    </div>
  );
}
