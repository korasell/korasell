import { notFound } from "next/navigation";
import Link from "next/link";

import { Navbar } from "@/components/navbar";
import { CopyLinkButton } from "@/components/copy-link-button";
import { BuyButton } from "@/components/checkout/buy-button";
import { prisma } from "@/lib/prisma";
import { formatPrice } from "@/lib/utils";

const TYPE_LABELS: Record<string, string> = {
  DIGITAL: "Produit numérique",
  PHYSICAL: "Produit physique",
  SERVICE: "Service",
};

export default async function ProductPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;

  const product = await prisma.product.findUnique({
    where: { slug, status: "PUBLISHED" },
    include: {
      images: { orderBy: { position: "asc" } },
      store: { select: { name: true, slug: true } },
      reviews: { select: { rating: true } },
    },
  });

  if (!product) notFound();

  const productUrl = `${process.env.NEXT_PUBLIC_APP_URL}/produit/${product.slug}`;
  const avgRating =
    product.reviews.length > 0
      ? (
          product.reviews.reduce((sum, r) => sum + r.rating, 0) /
          product.reviews.length
        ).toFixed(1)
      : null;

  const outOfStock =
    product.type === "PHYSICAL" &&
    product.stockQuantity !== null &&
    product.stockQuantity <= 0;

  return (
    <div>
      <Navbar />

      <section className="mx-auto grid max-w-5xl grid-cols-1 gap-8 px-4 py-10 md:grid-cols-2">
        <div>
          <div className="aspect-square overflow-hidden rounded-lg bg-slate-100">
            {product.images[0] && (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={product.images[0].url}
                alt={product.title}
                className="h-full w-full object-cover"
              />
            )}
          </div>
          {product.images.length > 1 && (
            <div className="mt-2 grid grid-cols-4 gap-2">
              {product.images.slice(1).map((img) => (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  key={img.id}
                  src={img.url}
                  alt=""
                  className="aspect-square rounded-md object-cover"
                />
              ))}
            </div>
          )}
        </div>

        <div>
          <span className="inline-block rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-600">
            {TYPE_LABELS[product.type]}
          </span>

          <h1 className="mt-3 text-2xl font-bold">{product.title}</h1>

          <Link
            href={`/boutique/${product.store.slug}`}
            className="text-sm text-slate-500 hover:underline"
          >
            Par {product.store.name}
          </Link>

          {avgRating && (
            <p className="mt-1 text-sm text-amber-600">
              ★ {avgRating} ({product.reviews.length} avis)
            </p>
          )}

          <p className="mt-4 text-3xl font-bold text-primary">
            {formatPrice(product.priceCents, product.currency)}
          </p>

          {product.description && (
            <p className="mt-4 whitespace-pre-line text-sm text-slate-700">
              {product.description}
            </p>
          )}

          {product.type === "PHYSICAL" && (
            <p className="mt-4 text-sm text-slate-600">
              {outOfStock
                ? "Rupture de stock"
                : `${product.stockQuantity} en stock`}
            </p>
          )}

          {product.type === "SERVICE" && product.serviceDurationMinutes && (
            <p className="mt-4 text-sm text-slate-600">
              Durée : {product.serviceDurationMinutes} min
              {product.serviceLocation && ` · ${product.serviceLocation}`}
            </p>
          )}

          <div className="mt-6 flex items-start gap-3">
            <BuyButton
              productId={product.id}
              type={product.type}
              outOfStock={outOfStock}
            />
            <CopyLinkButton url={productUrl} />
          </div>
        </div>
      </section>
    </div>
  );
}
