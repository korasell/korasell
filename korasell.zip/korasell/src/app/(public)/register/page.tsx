import Link from "next/link";
import { RegisterForm } from "@/components/auth/register-form";

export default function RegisterPage() {
  return (
    <div className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-4 py-12">
      <h1 className="mb-1 text-2xl font-bold text-primary">Créer un compte</h1>
      <p className="mb-6 text-sm text-slate-500">
        Rejoignez Korasell pour acheter ou vendre.
      </p>

      <RegisterForm />

      <p className="mt-6 text-center text-sm text-slate-500">
        Déjà un compte ?{" "}
        <Link href="/login" className="font-medium text-primary underline">
          Se connecter
        </Link>
      </p>
    </div>
  );
}
