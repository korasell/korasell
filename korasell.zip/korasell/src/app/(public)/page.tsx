import Link from "next/link";
import { Navbar } from "@/components/navbar";
import { prisma } from "@/lib/prisma";
import { formatPrice } from "@/lib/utils";

export default async function HomePage() {
  const products = await prisma.product.findMany({
    where: { status: "PUBLISHED" },
    orderBy: { createdAt: "desc" },
    take: 8,
    include: {
      images: { orderBy: { position: "asc" }, take: 1 },
      store: { select: { name: true, slug: true } },
    },
  });

  return (
    <div>
      <Navbar />

      <section className="mx-auto max-w-6xl px-4 py-16 text-center">
        <h1 className="text-4xl font-bold text-primary">
          Votre savoir mérite un marché
        </h1>
        <p className="mx-auto mt-4 max-w-xl text-slate-600">
          Vendez vos produits numériques, physiques ou vos services en
          quelques minutes, sans abonnement.
        </p>
        <div className="mt-8 flex justify-center gap-4">
          <Link
            href="/register"
            className="rounded-lg bg-primary px-5 py-3 text-primary-foreground hover:opacity-90"
          >
            Créer ma boutique
          </Link>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-16">
        <h2 className="mb-6 text-xl font-semibold">Produits récents</h2>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
          {products.map((product) => (
            <Link
              key={product.id}
              href={`/produit/${product.slug}`}
              className="rounded-lg border border-slate-200 bg-white p-3 transition hover:shadow-md"
            >
              <div className="mb-2 aspect-square overflow-hidden rounded-md bg-slate-100">
                {product.images[0] && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={product.images[0].url}
                    alt={product.title}
                    className="h-full w-full object-cover"
                  />
                )}
              </div>
              <p className="truncate text-sm font-medium">{product.title}</p>
              <p className="text-xs text-slate-500">{product.store.name}</p>
              <p className="mt-1 text-sm font-semibold text-primary">
                {formatPrice(product.priceCents, product.currency)}
              </p>
            </Link>
          ))}

          {products.length === 0 && (
            <p className="col-span-full text-sm text-slate-500">
              Aucun produit publié pour le moment.
            </p>
          )}
        </div>
      </section>
    </div>
  );
}
