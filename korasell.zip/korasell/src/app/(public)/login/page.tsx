import Link from "next/link";
import { LoginForm } from "@/components/auth/login-form";

export default function LoginPage() {
  return (
    <div className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-4">
      <h1 className="mb-1 text-2xl font-bold text-primary">Connexion</h1>
      <p className="mb-6 text-sm text-slate-500">
        Accédez à votre compte Korasell.
      </p>

      <LoginForm />

      <p className="mt-6 text-center text-sm text-slate-500">
        Pas encore de compte ?{" "}
        <Link href="/register" className="font-medium text-primary underline">
          Créer un compte
        </Link>
      </p>
    </div>
  );
}
