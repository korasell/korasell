import { notFound } from "next/navigation";
import Link from "next/link";

import { Navbar } from "@/components/navbar";
import { CopyLinkButton } from "@/components/copy-link-button";
import { prisma } from "@/lib/prisma";
import { formatPrice } from "@/lib/utils";

export default async function StorePage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;

  const store = await prisma.store.findUnique({
    where: { slug, isActive: true },
    include: {
      products: {
        where: { status: "PUBLISHED" },
        orderBy: { createdAt: "desc" },
        include: { images: { orderBy: { position: "asc" }, take: 1 } },
      },
    },
  });

  if (!store) notFound();

  const storeUrl = `${process.env.NEXT_PUBLIC_APP_URL}/boutique/${store.slug}`;

  return (
    <div>
      <Navbar />

      <section className="mx-auto max-w-6xl px-4 py-10">
        <div className="flex items-center gap-4">
          {store.logoUrl && (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={store.logoUrl}
              alt={store.name}
              className="h-16 w-16 rounded-full object-cover"
            />
          )}
          <div className="flex-1">
            <h1 className="text-2xl font-bold">{store.name}</h1>
            {store.description && (
              <p className="mt-1 text-sm text-slate-600">
                {store.description}
              </p>
            )}
          </div>
          <CopyLinkButton url={storeUrl} />
        </div>

        <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
          {store.products.map((product) => (
            <Link
              key={product.id}
              href={`/produit/${product.slug}`}
              className="rounded-lg border border-slate-200 bg-white p-3 transition hover:shadow-md"
            >
              <div className="mb-2 aspect-square overflow-hidden rounded-md bg-slate-100">
                {product.images[0] && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={product.images[0].url}
                    alt={product.title}
                    className="h-full w-full object-cover"
                  />
                )}
              </div>
              <p className="truncate text-sm font-medium">{product.title}</p>
              <p className="mt-1 text-sm font-semibold text-primary">
                {formatPrice(product.priceCents, product.currency)}
              </p>
            </Link>
          ))}

          {store.products.length === 0 && (
            <p className="col-span-full text-sm text-slate-500">
              Cette boutique n&apos;a pas encore de produit publié.
            </p>
          )}
        </div>
      </section>
    </div>
  );
}
