import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Korasell — Votre savoir mérite un marché",
  description:
    "La marketplace pour vendre vos produits numériques, physiques et services.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fr">
      <body className="min-h-screen antialiased">{children}</body>
    </html>
  );
}
