import NextAuth from "next-auth";
import { authConfig } from "@/auth.config";

export const { auth: middleware } = NextAuth(authConfig);

export const config = {
  // Protège tout /dashboard/* ; laisse passer le reste (pages publiques, api, assets)
  matcher: ["/dashboard/:path*"],
};
